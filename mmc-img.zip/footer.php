<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>About Us</h6>
								<p>
									Muhabura Multichoice Company Ltd was registered by Rwanda Development Board and is fully owned by the Government of Rwanda, under Rwanda Correctional Services (RCS). 
								</p>
								<p class="footer-text">
									
                              Copyright &copy; 2018 MMC. All rights reserved | Powered by <a href="https://progressmih.com" target="_blank">ProgressMih</a>

								</p>								
							</div>
						</div>
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>Useful Links</h6>
								<p><a href="http://mail.mmc.rw/webmail" target="_blank"><i class="fa fa-envelope" style="font-size: 18px;"> Access Mail</i></a></p>
								
							</div>
						</div>						
						<div class="col-lg-2 col-md-6 col-sm-6 social-widget">
							<div class="single-footer-widget">
								<h6>Follow Us</h6>
								<p>Stay Update</p>
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
								
								</div>
							</div>
						</div>							
					</div>
				</div>
			</footer>