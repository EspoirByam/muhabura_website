           <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				  				<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									
				  				</ul>
				  			</div>
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
				  				
				  				<a style="font-size:20px;" href="muhabura" target="_blank" ><b>MMC-IRS-MIS</b></a>				
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="<?php echo '?tab='.md5('main') ?>"><img src="img/mmc.jpg" alt="mmc" title="mmc" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="<?php echo '?tab='.md5('main') ?>">Home</a></li>
				          <li><a href="<?php echo '?tab='.md5('about') ?>">About Us</a></li>
				          <li><a href="<?php echo '?tab='.md5('service') ?>">What We Do</a></li>
				          <li><a href="#">Projects</a>
				          	<ul>
				          		<li><a href="<?php echo '?tab='.md5('project') ?>">Finished Project</a></li>
				          		<li><a href="<?php echo '?tab='.md5('project1') ?>">Ongoing Project</a></li>
				          	</ul>
				          </li>
				           <li><a href="<?php echo '?tab='.md5('media') ?>">Media Center</a>
				           	<ul>
				           		<li><a href="<?php echo '?tab='.md5('media') ?>">News</a></li>
				           		<li><a href="<?php echo '?tab='.md5('video') ?>">Videos</a></li>
				           		<li><a href="<?php echo '?tab='.md5('gallery') ?>">Gallery</a></li>
				           		<li><a href="<?php echo '?tab='.md5('communication') ?>">Communication</a></li>
				           		<li><a href="#">Social media</a></li>
				           	</ul>

				           </li>     					          
				          <li><a href="<?php echo '?tab='.md5('contact') ?>">Contact</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header>