  <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>MUHABURA MULTICHOICE COMPANY LTD &copy; 2018</p>
                </div>
                
                <div class="col-sm-6 text-right">
                  <p>Designed by <a href="http://www.progressmih.com" target="_blank" > ProgressMiH</a></p>                
                </div>
              </div>
            </div>
          </footer>