      <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/sb.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4">Joseph Haule</h1>
              <p>Administrator</p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
            <ul class="list-unstyled">
                <li ><a href="<?php echo '?tab='.md5('home') ?>"> <i class="icon-home"></i>Home </a></li>
                <li><a href="<?php echo '?tab='.md5('news_list') ?>"> <i class="fa fa-file-o"></i>News </a>
                  
                </li>
                <li><a href="<?php echo '?tab='.md5('communication') ?>"> <i class="icon-padnote"></i>Comunication </a>
                </li>
                <li><a href="<?php echo '?tab='.md5('project') ?>"> <i class="fa fa-tasks"></i>Project </a>
                </li>
                <li><a href="#media" aria-expanded="false" data-toggle="collapse"> <i class="icon-screen"></i>Media Center</a>
                   <ul id="media" class="collapse list-unstyled ">
                      <li><a href="<?php echo '?tab='.md5('images') ?>"><i class="icon-picture"></i> Images</a></li>
                      <li><a href="<?php echo '?tab='.md5('videos') ?>"><i class="icon-screen"></i> Videos</a></li>
                      <li><a href="#">Social media</a></li>
                    </ul>
                </li>
                <li><a href="<?php echo '?tab='.md5('user') ?>"> <i class="fa fa-users"></i>User</a>
                   
                </li>
                               
           </ul>       
        </nav>


