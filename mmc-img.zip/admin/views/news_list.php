<?php 

include("./core/db.php");


 $db= new DB();
 $conn = $db->__construct();
$table = "news";

?>
  <div class="col-lg-12" style="padding-top: 5px;">
    <div class="card">
      <div class="card-close">
        <div class="dropdown">
          <button type="button" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" class="btn btn-sm btn-success"><i class="fa fa-plus-o"></i>Add News</button>
        </div>
      </div>
      <div class="card-header d-flex align-items-center">
        <h3 class="h4">List of News</h3>
      </div>
      <div class="card-body">
        <div class="table-responsive">  
          <table class="table table-striped">
            <thead>
              <tr>
                <th >#ID</th>
                <th>Title</th>
                <th>Image</th>
                <th>Description</th>
                <th>Detail</th>
                <th width="12%">Date</th>
                <th width="15%">Edit</th>
              </tr>
            </thead>
            <tbody>
           
      <?php

        $parcourt = $conn->query("SELECT * FROM news ORDER BY id ASC");

        while($fromdb = $parcourt -> fetch()){

          
      
           
            
            echo"
            <tbody>
              <tr>
                <th scope=\"row\">".$fromdb['id']."</th>
                <td>".$fromdb['title']."</td>
                <td><img src=\"./images/".$fromdb['image']."\" style=\"width:70px; height:70px;\"></td>
                <td>".$fromdb['description']."</td>
                <td>".$fromdb['detail']."</td>
                <td>".$fromdb['date']."</td>
                <td><button class=\"btn btn-sm btn-primary\" data-toggle=\"modal\" data-target=\"#editModel_".$fromdb['id']."\">Edit</button> 
                <a href=\"./class/newscontrolor.php?id=".$fromdb['id']."\" class=\"btn btn-sm btn-danger\" onclick=\"return confirm('Delete this news?');\">Remove</a></td>
              </tr>";  

              ?>

              <!--model for updating-->

<div class="modal fade" id="editModel_<?php echo $fromdb['id']; ?>"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update News</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <?php 
            $id = $fromdb['id'];
          $getUp = $conn->query("SELECT * FROM news WHERE id ='$id'");

        while($fromdbup = $getUp -> fetch()){
        
?>
        <form action="./class/newscontrolor.php" method="post" enctype="multipart/form-data">
          <div class="form-group row">
                <label for="title" class="col-sm-2 col-form-label">Title</label>            
            <div class="col-sm-10">           
              <input type="text" class="form-control" value="<?php echo $fromdbup["title"];?>" id="title" name="titlenews">
            </div>
          </div>         
          <div class="form-group row">
            <label for="Image" class="col-sm-2 col-form-label">Image</label>
            <div class="col-sm-10" >
                <input type="file" name="img"  id="image"><?php echo $fromdbup["image"];?>
            </div>
          </div>

          <input type="hidden" name="id" value="<?php echo $fromdb['id']; ?>"">
           <div class="form-group row">
            <label for="description" class="col-sm-2 col-form-label">Descript.</label>
            <div class="col-sm-10">
                 <textarea class="form-control" id="message-text" name="descriptionnews"><?php echo $fromdbup["description"];?></textarea>
           </div>
          </div>
          <div class="form-group row">
            <label for="detail" class="col-sm-2 col-form-label">Detail</label>
            <div class="col-sm-10">
               <textarea class="form-control" id="message-text"  name="detailnews"><?php echo $fromdbup["detail"];?></textarea>
            </div>
          </div>
          
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary" name="btn_upnews">Save</button>
      </div>

      </form>
    </div>
  </div>
</div>




              <?php 
            
           }
          
          }


              // $condit= array('order by'=>'id asc');
              // $fromdb=$db->getRows($table,$condit);
            
              ?>
                 
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add News</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./class/newscontrolor.php" method="post" enctype="multipart/form-data">
          <div class="form-group row">
                <label for="title" class="col-sm-2 col-form-label">Title</label>            
            <div class="col-sm-10">           
              <input type="text" class="form-control" id="title" name="titlenews">
            </div>
          </div>         
          <div class="form-group row">
            <label for="Image" class="col-sm-2 col-form-label">Image</label>
            <div class="col-sm-10" >
                <input type="file" name="img"  id="image">
            </div>
          </div>
           <div class="form-group row">
            <label for="description" class="col-sm-2 col-form-label">Descript.</label>
            <div class="col-sm-10">
                 <textarea class="form-control" id="message-text" name="descriptionnews"></textarea>
           </div>
          </div>
          <div class="form-group row">
            <label for="detail" class="col-sm-2 col-form-label">Detail</label>
            <div class="col-sm-10">
               <textarea class="form-control" id="message-text" name="detailnews"></textarea>
            </div>
          </div>
          
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary" name="btn_addnews">Save</button>
      </div>

      </form>
    </div>
  </div>
</div>


