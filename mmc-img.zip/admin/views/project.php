<?php

include("./core/db.php");


 $db= new DB();
 $conn = $db->__construct();
$table = "projet";
?>
  <div class="col-lg-12" style="padding-top: 5px;">
    <div class="card">
      <div class="card-close">
        <div class="dropdown">
          <button type="button" data-toggle="modal" data-target="#new_project" data-whatever="@mdo" class="btn btn-sm btn-success"><i class="fa fa-plus-o"></i>Add Project</button>
        </div>
      </div>
      <div class="card-header d-flex align-items-center">
        <h3 class="h4">List of Projects</h3>
      </div>
      <div class="card-body">
        <div class="table-responsive">  
          <table class="table table-striped">
            <thead>
              <tr>
                <th >#ID</th>
                <th>Title</th>
                <th>Image</th>
                <th>Description</th>
                <th>Status</th>
                <th width="12%">Date</th>
                <th width="15%">Edit</th>
              </tr>
            </thead>
            <tbody>
              
              <?php

        $parcourt = $conn->query("SELECT * FROM projet ORDER BY id ASC");

        while($fromdb = $parcourt -> fetch()){

          
      
           
            
            echo"
            <tbody>
              <tr>
                <th scope=\"row\">".$fromdb['id']."</th>
                <td>".$fromdb['title']."</td>
                <td><img src=\"./images/".$fromdb['image']."\" style=\"width:70px; height:70px;\"></td>
                <td>".$fromdb['description']."</td>
                <td>".$fromdb['status']."</td>
                <td>".$fromdb['date']."</td>
                <td><button class=\"btn btn-sm btn-primary\" data-toggle=\"modal\" data-target=\"#editModel_".$fromdb['id']."\">Edit</button> 
                <a href=\"./class/projectcontrolor.php?id=".$fromdb['id']."\" class=\"btn btn-sm btn-danger\" onclick=\"return confirm('Delete this Project?');\">Remove</a></td>
              </tr>";  ?>
            
           
           <!--model for updating-->

<div class="modal fade" id="editModel_<?php echo $fromdb['id']; ?>"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Project</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <?php 
            $id = $fromdb['id'];
          $getUp = $conn->query("SELECT * FROM projet WHERE id ='$id'");

        while($fromdbup = $getUp -> fetch()){
        
?>
        <form action="./class/projectcontrolor.php" method="post" enctype="multipart/form-data">
          <div class="form-group row">
                <label for="title" class="col-sm-2 col-form-label">Title</label>            
            <div class="col-sm-10">           
              <input type="text" class="form-control" value="<?php echo $fromdbup["title"];?>" id="title" name="titleprojectup">
            </div>
          </div>         
          <div class="form-group row">
            <label for="Image" class="col-sm-2 col-form-label">Image</label>
            <div class="col-sm-10" >
                <input type="file" name="imgup"  id="image"><?php echo $fromdbup["image"];?>
            </div>
          </div>

          <div class="form-group row">
                <label for="Status" class="col-sm-2 col-form-label">Status</label>            
            <div class="col-sm-10">           
              <select class="form-control" id="title" name="statusprojectup">
                <option value="<?php echo $fromdbup["status"];?>"><?php echo $fromdbup["status"];?></option>
                <option value="Ongoing">Ongoing</option>
                <option value="Finished">Finished</option>
                </select>
            </div>
          </div>  

          <input type="hidden" name="id" value="<?php echo $fromdb['id']; ?>"">
           <div class="form-group row">
            <label for="description" class="col-sm-2 col-form-label">Descript.</label>
            <div class="col-sm-10">
                 <textarea class="form-control" id="message-text" name="descriptionprojectup"><?php echo $fromdbup["description"];?></textarea>
           </div>
          </div>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary" name="btn_upproject">Save</button>
      </div>

      </form>
    </div>
  </div>
</div>




              <?php 
            
           }
          
          }


              // $condit= array('order by'=>'id asc');
              // $fromdb=$db->getRows($table,$condit);
            
              ?>

            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


<div class="modal fade" id="new_project" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Project</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./class/projectcontrolor.php" method="post" enctype="multipart/form-data">
          <div class="form-group row">
                <label for="title" class="col-sm-2 col-form-label">Title:</label>            
            <div class="col-sm-10">           
              <input type="text" class="form-control" id="title" name="titleproject">
            </div>
          </div> 
          <div class="form-group row">
                <label for="Status" class="col-sm-2 col-form-label">Status</label>            
            <div class="col-sm-10">           
              <select class="form-control" id="title" name="statusproject">
                <option value="0">[ Select ]</option>
                <option value="Ongoing">Ongoing</option>
                <option value="Finished">Finished</option>
                </select>
            </div>
          </div>         
          <div class="form-group row">
            <label for="Image" class="col-sm-2 col-form-label">Image:</label>
            <div class="col-sm-10" >
                <input type="file"  id="image" name="img">
            </div>
          </div>
           <div class="form-group row">
            <label for="description" class="col-sm-2 col-form-label">Description:</label>
            <div class="col-sm-10">
                 <textarea class="form-control" id="message-text" name="descriptionproject"></textarea>
           </div>
          </div> 

          <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <input type="submit" class="btn btn-primary" value="Save" name="saveproject" />
      </div>         
        </form>
      </div>
      
    </div>
  </div>
</div>