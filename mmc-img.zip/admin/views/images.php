<?php 

include("./core/db.php");


 $db= new DB();
 $conn = $db->__construct();
$table = "images";

?>
<style type="text/css">
	img{
		height: 200px;
		width: 250px;
	}
</style>
 <div class="breadcrumb-holder container-fluid">
    <ul class="breadcrumb">      
      <li class="breadcrumb-item pull-right" ><button class="btn btn-sm btn-success" data-toggle="modal" data-target="#new_image">Add Image</button></li>
    </ul>
    <div class="pull-right">
    	
    </div>
  </div>
 <div class="container-fluid" style="padding-top: 5px;">
    <div class="row" >
	

		<?php

        $parcourt = $conn->query("SELECT * FROM images ORDER BY id ASC");

        while($fromdb = $parcourt -> fetch()){

          
      
           
            
            echo"
            <div class=\"col-md-3\">
                <img src=\"./images/".$fromdb['dir']."\"class=\"img-responsive\">
                <div class=\"center\" align=\"center\" style=\"padding-top: 2px;\">
	                <a href=\"./class/imagecontrolor.php?id=".$fromdb['id']."\" class=\"btn btn-sm btn-outline-danger\" onclick=\"return confirm('Delete this Image?');\"> Remove</a>
			        <a class=\"btn btn-sm btn-outline-success\"> Publish</a>
	        	</div>
            </div>";   
            
           
          
          }


              // $condit= array('order by'=>'id asc');
              // $fromdb=$db->getRows($table,$condit);
            
              ?>



	</div>	
</div>



  <div class="modal fade" id="new_image" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="image">Add Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./class/imagecontrolor.php" method="post" enctype="multipart/form-data">
                  
          <div class="form-group row">
            <label for="Image" class="col-sm-2 col-form-label">Image:</label>
            <div class="col-sm-10" >
                <input type="file" name="img"  id="image">
            </div>
          </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <input type="submit" class="btn btn-primary" value="Save" name="btnimage" />
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>