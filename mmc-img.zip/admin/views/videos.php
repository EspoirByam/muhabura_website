<?php 

include("./core/db.php");


 $db= new DB();
 $conn = $db->__construct();
$table = "videos";

?>
<style type="text/css">
	img{
		height: 200px;
		width: 250px;
	}
</style>
 <div class="breadcrumb-holder container-fluid">
    <ul class="breadcrumb">      
      <li class="breadcrumb-item pull-right" ><button class="btn btn-sm btn-success" data-toggle="modal" data-target="#new_image">Add Video</button></li>
    </ul>
    <div class="pull-right">
    	
    </div>
  </div>
 <div class="container-fluid" style="padding-top: 5px;">
    <div class="row" >

		<?php

        $parcourt = $conn->query("SELECT * FROM videos ORDER BY id ASC");

        while($fromdb = $parcourt -> fetch()){

          
      
           
            
             echo"
            <div class=\"col-md-3\">

            <iframe id=\"ytplayer\" type=\"text/html\" src=\"http://www.youtube.com/embed/u1zgFlCw8Aw?autoplay=1&origin=http://example.com\" frameborder=\"0\"/>
            	
            	
                
            </div>
            <div class=\"center\" align=\"center\" style=\"padding-top: 2px;\">
	                <a href=\"./class/imagecontrolor.php?id=".$fromdb['id']."\" class=\"btn btn-sm btn-outline-danger\" onclick=\"return confirm('Delete this Image?');\"> Remove</a>
			        <a class=\"btn btn-sm btn-outline-success\"> Publish</a>
	        	</div>";   
            
           
          
          }


              // $condit= array('order by'=>'id asc');
              // $fromdb=$db->getRows($table,$condit);
            
              ?>
                 


	</div>	
</div>



  <div class="modal fade" id="new_image" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="image">Add Video</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./class/videoscontrolor.php" method="post" enctype="multipart/form-data">
                  
          <div class="form-group row">
            <label for="Image" class="col-sm-2 col-form-label">Link</label>
            <div class="col-sm-10" >
                <input type="text" name="videolink" class="form-control" id="video" placeholder="video link" >
            </div>
          </div>
          <div class="form-group row">
            <label for="title" class="col-sm-2 col-form-label">Title</label>
            <div class="col-sm-10" >
                <input type="text" name="title" class="form-control" id="title1" placeholder="Title" >
            </div>
          </div>

          <div class="form-group row">
            <label for="description" class="col-sm-2 col-form-label">Descript.</label>
            <div class="col-sm-10">
                 <textarea class="form-control" id="message-text" name="descriptionvideo"></textarea>
           </div>
          </div>
          
          <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
	        <input type="submit" class="btn btn-primary" name="btnvideos" value="Save"/>
      	  </div>

        </form>
      </div>
    </div>
  </div>
</div>