 <?php 

include("./core/db.php");
 $db= new DB();
 $conn = $db->__construct();

 ?>
  <div class="col-lg-12" style="padding-top: 5px;">
    <div class="card">
      <div class="card-close">
        <div class="dropdown">
          <button type="button" data-toggle="modal" data-target="#new_communication" class="btn btn-sm btn-success"><i class="fa fa-plus-o"></i>New Communication</button>
        </div>
      </div>
      <div class="card-header d-flex align-items-center">
        <h3 class="h4">List of communications</h3>
      </div>
      <div class="card-body">
        <div class="table-responsive">  
          <table class="table table-striped">
            <thead>
              <tr>
                <th >#ID</th>
                <th>Title</th>
                <th>Description</th>
                <th width="12%">Date</th>
                <th width="15%">Edit</th>
              </tr>
            </thead>
            <tbody>
              <?php

        $parcourt = $conn->query("SELECT * FROM communication ORDER BY id ASC");

        while($fromdb = $parcourt -> fetch()){

          
      
           
            
            echo"
            <tbody>
              <tr>
                <th scope=\"row\">".$fromdb['id']."</th>
                <td>".$fromdb['title']."</td>
                <td>".$fromdb['description']."</td>
                <td>".$fromdb['date']."</td>
                <td><button class=\"btn btn-sm btn-primary\" data-toggle=\"modal\" data-target=\"#editModel_".$fromdb['id']."\">Edit</button> 
                <a href=\"./class/communicationcontrolor.php?id=".$fromdb['id']."\" class=\"btn btn-sm btn-danger\" onclick=\"return confirm('Delete this Communication?');\">Remove</a></td>
              </tr>";   
            
          ?>
              <!--model for updating-->

<div class="modal fade" id="editModel_<?php echo $fromdb['id']; ?>"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Communication</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <?php 
            $id = $fromdb['id'];
          $getUp = $conn->query("SELECT * FROM communication WHERE id ='$id'");

        while($fromdbup = $getUp -> fetch()){
        
?>
        <form action="./class/communicationcontrolor.php" method="post" enctype="multipart/form-data">
          <div class="form-group row">
                <label for="title" class="col-sm-2 col-form-label">Title</label>            
            <div class="col-sm-10">           
              <input type="text" class="form-control" value="<?php echo $fromdbup["title"];?>" id="title" name="titlecommunicationup">
            </div>
          </div>         

          <input type="hidden" name="id" value="<?php echo $fromdb['id']; ?>"">
           <div class="form-group row">
            <label for="description" class="col-sm-2 col-form-label">Descript</label>
            <div class="col-sm-10">
                 <textarea class="form-control" id="message-text" name="descriptioncommunicationup"><?php echo $fromdbup["description"];?></textarea>
           </div>
          </div>
          
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary" name="btn_upcommuncation">Save</button>
      </div>

      </form>
    </div>
  </div>
</div>




              <?php 
            
           }
          
          }


              // $condit= array('order by'=>'id asc');
              // $fromdb=$db->getRows($table,$condit);
            
              ?>
                 
              

         


            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


<div class="modal fade" id="new_communication" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New Communication</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./class/communicationcontrolor.php" method="post" enctype="multipart/form-data">
          <div class="form-group row">
                <label for="title" class="col-sm-2 col-form-label">Title:</label>            
            <div class="col-sm-10">           
              <input type="text" class="form-control" id="title" name="titlecommunication">
            </div>
          </div>         
           <div class="form-group row">
            <label for="description" class="col-sm-2 col-form-label">Descript.</label>
            <div class="col-sm-10">
                 <textarea class="form-control" id="message-text" name="descriptioncommunication"></textarea>
           </div>
          </div>
          <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <input type="submit" class="btn btn-primary" name="bdtncommunication" value="Save"/>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>
