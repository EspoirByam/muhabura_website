<?php 

include("../core/db.php");


$db= new DB();
$table = "news";

$condit= array('order by'=>'id asc');
$fromdb=$db->getRows($table,$condit);

foreach ($fromdb as $cop_id):
	$cop_id=$fromdb["id"];
echo $cop_id; 

endforeach; 

?>