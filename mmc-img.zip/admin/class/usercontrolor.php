<?php

include("../core/db.php");

$db= new DB();
$table = "user";

if(isset($_POST['btnuser']))
{
	 			$names = $_POST["names1"];
				$title = $_POST["title1"];
				$email = $_POST["email1"];
				$path = "../images/";
				$field = "img";

				$nameImage = $db->upload($path,$field);

				$today = date("Y/m/d");

				$data = array("title"=>$title,"image"=>$nameImage,"names"=>$names,"email"=>$email,"date"=>$today);


				if($db->insert($table,$data))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('user'));

				}
				else
				{
					echo "echec";
				}

}

if(isset($_GET['id']))
{

	$myid = $_GET['id'];

	$condition = array("id"=>$myid);

	if($db->delete($table,$condition))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('user'));

				}
				else
				{
					echo "echec";
				}



}

if (isset($_POST["btn_upuser"])) {
				
				$names = $_POST["namesuserup"];
				$title = $_POST["titleuserup"];
				$email = $_POST["emailuserup"];
				$path = "../images/";
				$field = "imgup";

				$nameImage = $db->upload($path,$field);

				$today = date("Y/m/d");

				$data = array("title"=>$title,"image"=>$nameImage,"names"=>$names,"email"=>$email,"date"=>$today);

				$myid = $_POST['id'];

				$conditions = array("id"=>$myid);


				if($db->update($table,$data,$conditions))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('user'));

				}
				else
				{
					echo "echec";
				}

}

?>