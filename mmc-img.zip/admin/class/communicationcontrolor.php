<?php
//start of registrating a news 

include("../core/db.php");

 $db= new DB();
 $conn = $db->__construct();
$table = "communication";

if(isset($_POST['bdtncommunication']))
 {

	$titlecommunication = $_POST["titlecommunication"];
	$descriptioncommunication = $_POST["descriptioncommunication"];
				
	$today = date("Y/m/d");

				$data = array("title"=>$titlecommunication,"description"=>$descriptioncommunication,"date"=>$today);


				if($db->insert($table,$data))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('communication'));

				}
				else
				{
					echo "echec";
				}}



if(isset($_GET['id']))
{

	$myid = $_GET['id'];

	$condition = array("id"=>$myid);

	if($db->delete($table,$condition))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('communication'));

				}
				else
				{
					echo "echec";
				}

	
}

if (isset($_POST["btn_upcommuncation"])) {
	
	$titlecommunication = $_POST["titlecommunicationup"];
	$descriptioncommunication = $_POST["descriptioncommunicationup"];

				
	$today = date("Y/m/d");

				$data = array("title"=>$titlecommunication,"description"=>$descriptioncommunication,"date"=>$today);

				$myid = $_POST['id'];

				$conditions = array("id"=>$myid);



				if($db->update($table,$data,$conditions))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('communication'));

				}
				else
				{
					echo "echec";
				}
}
?>