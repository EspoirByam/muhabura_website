<?php

include("../core/db.php");

$db= new DB();
$conn = $db->__construct();
$table = "videos";


if(isset($_POST['btnvideos']))
{

				$videolink1 = $_POST["videolink"];


				$title = $_POST["title"];
				$descriptionvideo1 = $_POST["descriptionvideo"];

				echo $descriptionvideo1;
				
				$data = array("title"=>$title,"dir"=>$videolink1,"description"=>$descriptionvideo1);


				if($db->insert($table,$data))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('videos'));

				}
				else
				{
					echo "echec";
				}


}

if(isset($_GET['id']))
{
$myid = $_GET['id'];
$condition = array("id"=>$myid);
if($db->delete($table,$condition))
{
echo "<script/text>alert(\"Well saved\");</script>";
header("Location:../index.php?tab=".md5('images'));
}
else
{
echo "echec";
}	
}

?>