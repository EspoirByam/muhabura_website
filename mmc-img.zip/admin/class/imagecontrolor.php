<?php

include("../core/db.php");

$db= new DB();
$conn = $db->__construct();
$table = "images";


if(isset($_POST['btnimage']))
{
$path = "../images/";
$field = "img";
$nameImage = $db->upload($path,$field);

$data = array("dir"=>$nameImage);

if($db->insert($table,$data))
{
echo "<script/text>alert(\"Well saved\");</script>";
header("Location:../index.php?tab=".md5('images'));
}
else
{
	echo "echec";
}
}

if(isset($_GET['id']))
{
$myid = $_GET['id'];
$condition = array("id"=>$myid);
if($db->delete($table,$condition))
{
echo "<script/text>alert(\"Well saved\");</script>";
header("Location:../index.php?tab=".md5('images'));
}
else
{
echo "echec";
}	
}

?>