<?
//start of registrating a news 

include("../core/db.php");

$db= new DB();
$table = "projet";

if(isset($_POST['saveproject']))
{

                $titleproject = $_POST["titleproject"];
				$statusproject = $_POST["statusproject"];
				$descriptionproject = $_POST["descriptionproject"];
				$path = "../images/";
				$field = "img";

				$nameImage = $db->upload($path,$field);

				$today = date("Y/m/d");

				$data = array("title"=>$titleproject,"image"=>$nameImage,"description"=>$descriptionproject,"status"=>$statusproject,"date"=>$today);


				if($db->insert($table,$data))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('project'));

				}
				else
				{
					echo "echec";
				}
				
}

if(isset($_GET['id']))
{

	$myid = $_GET['id'];

	$condition = array("id"=>$myid);

	if($db->delete($table,$condition))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('project'));

				}
				else
				{
					echo "echec";
				}

	
}

if (isset($_POST["btn_upproject"])) {
	
				$titleproject = $_POST["titleprojectup"];
				$statusproject = $_POST["statusprojectup"];
				$descriptionproject = $_POST["descriptionprojectup"];
				$path = "../images/";
				$field = "imgup";

				$nameImage = $db->upload($path,$field);

				$today = date("Y/m/d");

				$data = array("title"=>$titleproject,"image"=>$nameImage,"description"=>$descriptionproject,"status"=>$statusproject,"date"=>$today);

				$myid = $_POST['id'];

				$conditions = array("id"=>$myid);


				if($db->update($table,$data,$conditions))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('project'));

				}
				else
				{
					echo "echec";
				}}

?>