<?php
session_start();
include("../core/db.php");

$db= new DB();
$conn = $db->__construct();
$table = "admin";

$admin_mail = $_POST["emailadmin"];
$admin_pass = $_POST["loginpassword"];
$submitting = $_POST["submitlog"];

$Condition = array("email"=>$admin_mail,"password"=>$admin_pass);

if (isset($submitting)) {

if($db->login($table,$Condition))
{ 
	$parcourt = $conn->query("SELECT * FROM admin WHERE email = '$admin_mail' AND password = '$admin_pass'");

        if($fromdb = $parcourt -> fetch())
        	{
        		$username = $fromdb["username"];
        	}
	$_SESSION["username_session"]=$username;
	header("Location:../index.php");

}
else
{

	echo "<script>alert(\"Password or Email Incorecct\");</script>";

	header("Location:login.php");
}


}
else
{

}

?>