<?
//start of registaring a news 

include("../core/db.php");

$db= new DB();
$conn = $db->__construct();
$table = "news";

if(isset($_POST['btn_addnews']))
{

                $titlenews = $_POST["titlenews"];
				$descriptionnews = $_POST["descriptionnews"];
				$detailnews = $_POST["detailnews"];
				$path = "../images/";
				$field = "img";

				$nameImage = $db->upload($path,$field);

				$today = date("Y/m/d");

				$data = array("title"=>$titlenews,"image"=>$nameImage,"description"=>$descriptionnews,"detail"=>$detailnews,"date"=>$today);


				if($db->insert($table,$data))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('news_list'));

				}
				else
				{
					echo "echec";
				}
				
}

if(isset($_GET['id']))
{

	$myid = $_GET['id'];

	$condition = array("id"=>$myid);

	if($db->delete($table,$condition))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('news_list'));

				}
				else
				{
					echo "echec";
				}

	
}

if (isset($_POST["btn_upnews"])) {


				$myid = $_POST['id'];

				$conditions = array("id"=>$myid);

				$titlenews = $_POST["titlenews"];
				$descriptionnews = $_POST["descriptionnews"];
				$detailnews = $_POST["detailnews"];
				$path = "../images/";
				$field = "img";

				$nameImage = $db->upload($path,$field);

				$today = date("Y/m/d");

				$data = array("title"=>$titlenews,"image"=>$nameImage,"description"=>$descriptionnews,"detail"=>$detailnews,"date"=>$today);

				if($db->update($table,$data,$conditions))
				{
					echo "<script/text>alert(\"Well saved\");</script>";
					header("Location:../index.php?tab=".md5('news_list'));

				}
				else
				{
					echo "echec";
				}
				
	
}



?>