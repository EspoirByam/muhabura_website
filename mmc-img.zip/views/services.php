	<!-- start banner Area -->
<section class="banner-area relative" id="home">	
	<div class="overlay overlay-bg"></div>
	<div class="container">				
		<div class="row d-flex align-items-center justify-content-center">
			<div class="about-content col-lg-12">
				<h1 class="text-white">
					What We Do				
				</h1>	
				<p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about.html"> Services</a></p>
			</div>	
		</div>
	</div>
</section>
<!-- End banner Area -->		


<!-- Start service Area -->
<section class="service-area section-gap" id="service">
	<div class="container">
						
		<div class="row">
			<div class="col-sm-2">
				<div class="single-service">
					<div class="thumb">
						<a href="#agriculture">
							<img src="img/agri.png" alt="">
						</a>									
					</div>
					<a href="#agriculture">
						<h4>Agriculture</h4>
					</a>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="single-service">
					<div class="thumb">
						<a href="#construction">
							<img src="img/construction.jpg" alt="">	
						</a>								
					</div>
					<a href="#construction">
						<h4>Construction</h4>
					</a>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="single-service">
					<div class="thumb">
						<a href="#soap">
							<img src="img/soap.png" alt="">
						</a>									
					</div>
					<a href="#soap">
						<h4>Soap Manufacturing</h4>
					</a>
				</div>
			</div>												
	
			<div class="col-sm-2">
				<div class="single-service">
					<div class="thumb">
						<a href="#supply">
							<img src="img/supp.png" alt="">
						</a>									
					</div>
					<a href="#supply">
						<h4>Supply</h4>
					</a>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="single-service">
					<div class="thumb">
						<a href="#wood">
							<img src="img/wood.jpeg" alt="">
						</a>									
					</div>
					<a href="#wood">
						<h4>Woodworking and Art Design</h4>
					</a>
				</div>
			</div>												
		</div>

	</div>	
</section>
<!-- End service Area -->					

<!-- Start blog-posts Area -->
<section class="blog-posts-area section-gap" >
	<div class="container">
		<div class="row">
			<div class="col-lg-10 post-list blog-post-list">
				<div class="single-post" >
				
					
					<a href="#" >
						<h1 id="agriculture">
							Agriculture
						</h1>
					</a>
					<div class="content-wrap">
						<p>
							The market of agricultural products is colossal in both in Rwanda and Esat African community as well. There is huge demand of maize, beans and horticulture products for local consumers and it would be more responsive if MMC Ltd professionally and commercially engages in this business. This will require the purchasing of modern machines with high performance yield. 
						</p>
						<p>
							In concrete words, MMC Ltd needs to engage in mechanized agriculture while diversifying crops (beans, maize and rice). In addition, vegetable farming can be potentially thought out as viable agriculture business, but a specific feasibility study will be needed to exhaustively determine its level of profitability.
						</p>

						<blockquote class="generic-blockquote">
							“Recently, the US Federal government banned online casinos from operating in America by making it illegal to transfer money to them through any US bank or payment system. As a result of this law, most of the popular online casino networks such as Party Gaming and PlayTech left the United States. Overnight, online casino players found themselves being chased by the Federal government.banking” 
						</blockquote>											


					</div>
			          <hr>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="blog-posts-area section-gap" >
	<div class="container">
		<div class="row" >
			<div class="col-lg-10 post-list blog-post-list">
				<div class="single-post">						
					
					<a href="#" id="construction">
						<h1>
							Construction
						</h1>
					</a>
					<div class="content-wrap">
						<p>
							Construction industry is one of the fastest growing industries in Rwanda and in East African community as well. That revealed, as a well-equipped and specialized company, MMC ltd will secure huge market share in Rwanda and in the region. Different ways to explore regional opportunities will be examined i.e. such as making strategic alliances with other regional companies operating in the industry. 
						</p>

						<blockquote class="generic-blockquote">
							The revenues from construction businesses can significantly increase if MMC LTD is equipped with machines and equipment that can be used in construction of both roads and buildings. 
						</blockquote>
							
						<h5>
							Investment
						</h5>	
						<p>
							With the above list of equipment to be acquired, MMC Ltd will be able to position itself at the best level of competition among its potential competitors in Rwanda and in the region as well. It is advisable that the company will extensively look for tenders in East African Community and The Common Market for Eastern and Southern Africa (COMESA). The purchase of equipment will be progressive in response to needs that are perceived imminent. 
						</p>							


					</div>
			          <hr>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="blog-posts-area section-gap" >
	<div class="container">
		<div class="row" >
			<div class="col-lg-10 post-list blog-post-list">
				<div class="single-post">
											
					<a href="#" id="soap">
						<h1>
							Soap Manufacturing
						</h1>
					</a>
					<div class="content-wrap">						

						<blockquote class="generic-blockquote">
							The soap is manufactured through the mixing of following basic raw materials: Palm oil, Caustic Acid, Kaolin (Whiting), coloring products and various small inputs (Sodium Silicate). As per now, the feasibility study for soap manufacturing at Huye Prison was developed is ready to be implemented. 
						</blockquote>
						<h5>
							Raw Materials
						</h5>
						<p>
							The raw materials required for the manufacturing of bar soap are mainly palm oil, caustic soda, fillers like sodium silicate, lime and soda ash to impart good quality and lower the cost of ingredients, additives like pigment colours (e.g. blue, white,etc), perfume like citronella and lemon, and Sodium laureth sulfate (SLES) for empowering the foam of soap. Most of the raw materials can be imported from East Africa countries and only lime is locally available. And certain inputs including human resource, utilities will be required once the operations begin.
						</p>							


					</div>
			          <hr>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="blog-posts-area section-gap" >
	<div class="container">
		<div class="row" >
			<div class="col-lg-10 post-list blog-post-list">
				<div class="single-post">
	
					
					<a href="#" id="garment">
						<h1>
							Garment Manufacturing
						</h1>
					</a>
					<div class="content-wrap">
						<p>
							Manufacturing is one of the fastest growing industries in Rwanda and in East African community as well. That revealed, as a well-equipped and specialized company, MMC ltd will secure huge market share in Rwanda and in the region. Different ways to explore regional opportunities will be examined i.e. such as making strategic alliances with other regional companies operating in the industry. 
						</p>

						<blockquote class="generic-blockquote">
							The revenues from construction businesses can significantly increase if MMC LTD is equipped with machines and equipment that can be used in construction of both roads and buildings. 
						</blockquote>
													


					</div>
			          <hr>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="blog-posts-area section-gap" >
	<div class="container">
		<div class="row" >
			<div class="col-lg-10 post-list blog-post-list">
				<div class="single-post">				
					
					<a href="#" id="supply">
						<h1>
							Supply
						</h1>
					</a>
					<div class="content-wrap">
						<p>
							MMC Ltd already implements general supply. Among the achievements in this regard, are the supply of food items in Bugesera and Rwamagana prisons.   Supply, especially food supply remains a critical business activity that would earn MMC Ltd a considerable profit, which would enable it, raise its share capital and extend investment in other profitable business. 
						</p>
						
						<blockquote class="generic-blockquote">
							For MMC Ltd. to extensively extend supply business, It is recommendable that a single source to supply food items to RCS be accorded  so that it can be able to earn consistent profit that can lead it to financial sustainability within few years. 
						</blockquote>
													


					</div>
			          <hr>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="blog-posts-area section-gap" >
	<div class="container">
		<div class="row">
			<div class="col-lg-10 post-list blog-post-list">
				<div class="single-post">
			
					
					<a href="#" id="wood">
						<h1>
							Woodworking and Art Design
						</h1>
					</a>
					<div class="content-wrap">
						<p>
							Between 2012 and 2014, major exports from Rwanda were over 83 billion Rwandan Francs ($108 million) and imports exceeded 133 billion Rwandan Francs. To mitigate this deficit, Rwanda’s Private Sector should heavily get involved in the production of products in order to decrease trade imbalance and adopt a Domestic Markets Recapturing strategy.
						</p>
						

						<blockquote class="generic-blockquote">
							“ In this respect, the government of Rwanda is determined to support all efforts to promote products made in the region as it targets a 28 per cent annual export growth by 2020. ” 
						</blockquote>
													


					</div>
			          <hr>
				</div>
			</div>
		</div>
	</div>
</section>

				
