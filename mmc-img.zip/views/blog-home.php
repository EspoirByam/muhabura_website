
			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Publications			
							</h1>	
							<p class="text-white link-nav"><a href="<?php echo '?tab='.md5('main') ?>">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="<?php echo '?tab='.md5('journal') ?>"> Publication</a> <span class="lnr lnr-arrow-right"></span> <a href="">The impact of agriculture in lives</a> </p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	
			
			<!-- Start blog-posts Area -->
			<section class="blog-posts-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-8 post-list blog-post-list">
							<div class="single-post">
								<img class="img-fluid" src="img/tea1.jpg" alt="">
								
								<a href="blog-single.html">
									<h1>
										The impact of agriculture in lives
									</h1>
								</a>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
										tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
										quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
										consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
										cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
									</p>

									

									<blockquote class="generic-blockquote">
										 "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
										 tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
										 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
										 consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
										 cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
										 proident, sunt in culpa qui officia deserunt mollit anim id est laborum.								
								      
								    </blockquote>
							</div>
							<hr>


																											
						</div>
						<div class="col-lg-4 sidebar">						

							<div class="single-widget recent-posts-widget">
								<h4 class="title">Recent Posts</h4>
								<div class="blog-list ">
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="img/tea1.jpg" height="100" width="100" alt="">
										</div>
										<div class="recent-details">
											<a href="blog-single.html">
												<h4>
													Home Audio Recording
													For Everyone
												</h4>
											</a>
											<p>
												02 hours ago
											</p>
										</div>
									</div>	
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="img/3.jpg" height="100" width="100" alt="">
										</div>
										<div class="recent-details">
											<a href="blog-single.html">
												<h4>
													Home Audio Recording
													For Everyone
												</h4>
											</a>
											<p>
												02 hours ago
											</p>
										</div>
									</div>	
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="img/1.jpg" height="100" width="100" alt="">
										</div>
										<div class="recent-details">
											<a href="blog-single.html">
												<h4>
													Home Audio Recording
													For Everyone
												</h4>
											</a>
											<p>
												02 hours ago
											</p>
										</div>
									</div>	
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="img/agr.jpeg" height="100" width="100" alt="">
										</div>
										<div class="recent-details">
											<a href="blog-single.html">
												<h4>
													Home Audio Recording
													For Everyone
												</h4>
											</a>
											<p>
												02 hours ago
											</p>
										</div>
									</div>	

									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="img/2.jpg" height="100" width="100" alt="">
										</div>
										<div class="recent-details">
											<a href="blog-single.html">
												<h4>
													Home Audio Recording
													For Everyone
												</h4>
											</a>
											<p>
												02 hours ago
											</p>
										</div>
									</div>	

									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="img/3.jpg" height="100" width="100" alt="">
										</div>
										<div class="recent-details">
											<a href="blog-single.html">
												<h4>
													Home Audio Recording
													For Everyone
												</h4>
											</a>
											<p>
												02 hours ago
											</p>
										</div>
									</div>																																					
								</div>								
							</div>			
						</div>
					</div>
				</div>	
			</section>
			<!-- End blog-posts Area -->
			
		