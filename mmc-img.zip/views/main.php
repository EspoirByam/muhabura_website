<!-- start banner Area -->
<section class="banner1-area relative" id="home" >
	

		<div class="active-review-carusel">
			<div class="single-feedback-carusel">
			   <a href="<?php echo '?tab='.md5('media') ?>">		
				 <img src="img/banner.png" height="500">
				 <div class="overlay text-left" style="padding-top: 12%; margin-left: 10%; margin-right: 5%">
				 	<h1 style="font-color: white;">
				        Soap Manufacturing
				          <br>
				         <small style="padding-top: 10px;">With main methods of making soap, the hot process and the cold ... We have been able to get our business off the ground ... </small>				         
				 	</h1>				 	
				 </div>
				</a>				
			</div>
			<div class="single-feedback-carusel">		
				 
				 <a href="<?php echo '?tab='.md5('media') ?>">
				 	<img src="img/tea1.jpg" height="500">

				 <div class="overlay text-left" style="padding-top: 12%; margin-left: 10%; margin-right: 5%">
				 	<h1 style="font-color: white;">
				         The impact of agriculture in lives
				          <br>
				         <small style="padding-top: 10px;">The importance of agriculture make us less dependent on other foreign countries, provides food and shelter and also provides us with income to the farmer and revenue to the government. </small>				         
				 	</h1>				 	
				 </div>	
				</a>			
			</div>

			<div class="single-feedback-carusel">
				<a href="<?php echo '?tab='.md5('media') ?>">
					<img  src="img/banner3.png" alt="" height="500">
					<div class="overlay text-left" style="padding-top: 12%; margin-left: 10%; margin-right: 5%">
					 	<h1 style="font-color: white;">
					         Woodworking and Art Design 
					          <br>
					         <small style="padding-top: 10px;">We activily make items with art design from wood, and includes cabinet making (cabinetry and furniture), wood carving, joinery, carpentry, and woodturning.</small>				         
					 	</h1>				 	
					 </div>
				 </a>	
			</div>
			
		</div>
	

</section>
<!-- End banner Area -->	
			

<!-- Start service Area -->
<section class="service-area section-gap" id="service">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-12 pb-30 header-text text-center">				
				<h4>
					We work in the following business sector
				</h4>
			</div>
		</div>						
		<div class="row">
			<div class="col-lg-4">
				<div class="single-service">
					<div class="thumb">
						<a href="<?php echo '?tab='.md5('service') ?>">
							<img src="img/agricu.png" alt="">
						</a>									
					</div>
					<h4>Agriculture</h4>
					<p>
						The market of agricultural products is colossal in both in Rwanda and Esat African community as well. There is huge demand of maize, beans and horticulture products for local consumers and it would be more responsive if MMC Ltd professionally and commercially engages in this business.
					</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="single-service">
					<div class="thumb">
						<a href="<?php echo '?tab='.md5('service') ?>">
							<img src="img/construction.jpg" alt="">
						</a>									
					</div>
					<h4>Construction</h4>
					<p>
						MMC ltd will secure huge market share in Rwanda and in the region. Different ways to explore regional opportunities will be examined i.e. such as making strategic alliances with other regional companies operating in the industry.
					</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="single-service">
					<div class="thumb">
						<a href="<?php echo '?tab='.md5('service') ?>">
							<img src="img/soap.png" alt="">
						</a>									
					</div>
					<h4>Soap Manufacturing</h4>
					<p>
						The soap is manufactured through the mixing of following basic raw materials: Palm oil, Caustic Acid, Kaolin (Whiting), coloring products and various small inputs (Sodium Silicate). As per now, the feasibility study for soap manufacturing at Huye Prison was developed is ready to be implemented. 
					</p>
				</div>
			</div>												
		</div> <br>

		<div class="row">
						
						<div class="col-lg-4">
							<div class="single-service">
								<div class="thumb">
									<a href="#supply">
										<img src="img/supp.png" alt="">
									</a>									
								</div>
								<a href="#supply">
									<h4>Supply</h4>
								</a>
								<p>
									The MMC supplies food items in Bugesera and Rwamagana prisons. Supply, especially food supply remains a critical business activity that would earn MMC Ltd a considerable profit, which would enable it, raise its share capital and extend investment in other profitable business.
								</p>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-service">
								<div class="thumb">
									<a href="#wood">
										<img src="img/wood1.png" alt="">
									</a>									
								</div>
								<a href="#wood">
									<h4>Woodworking and Art Design</h4>
								</a>
								<p>
									To mitigate this deficit, Rwanda’s Private Sector should heavily get involved in the production of products in order to decrease trade imbalance and adopt a Domestic Markets Recapturing strategy..
								</p>
							</div>
						</div>												
					</div>
         <a class="primary-btn" href="<?php echo '?tab='.md5('service') ?>">More about Services</a>
		

	</div>	
</section>
<!-- End service Area -->

<!-- Start home-about Area -->
<section class="home-about-area section-gap" id="about">
	<div class="container">
		<div class="row justify-content-center align-items-center">
			<div class="col-lg-8 col-md-12 home-about-left">

				<h1>
					Communications
					
				</h1>
				
				<div class="active-review-carusel">
						<div class="single-feedback-carusel">
							<div class="title d-flex flex-row">
								<h4 class="pb-10">The final test</h4>
																		
							</div>
							<p>
								The test of the new implementation of the announced program will be hold on Thursday 15TH 2018. All member of different department need to be there to get the overview of the work.
							</p>
						</div>
						<div class="single-feedback-carusel">
							<div class="title d-flex flex-row">
								<h4 class="pb-10">Program launch</h4>
																		
							</div>
							<p>
								The test of the new implementation of the announced program will be hold on Thursday 15TH 2018. All member of different department need to be there to get the overview of the work.
							</p>
						</div>
																						
					</div>
					
				</div>						
		</div>
	</div>	
</section>
<!-- End home-about Area -->
		

<!-- Start blog Area -->
<section class="blog-area section-gap" id="blog" style="padding-top: 3px;">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-12 pb-30 header-text">
				<h1>Latest posts</h1>
				
			</div>
		</div>
		<div class="row">	
			<div class="single-blog col-lg-4 col-md-4">
				<div class="thumb">
					<img class="f-img img-fluid mx-auto" src="img/tea1.jpg" alt="">	
				</div>
				<div class="bottom d-flex justify-content-between align-items-center flex-wrap">
					
					<div class="meta">
						13th Dec
			
					</div>
				</div>							
				<a href="#">
					<a href="<?php echo '?tab='.md5('journal') ?>">
						<h4>The impact of agriculture in lives</h4>
					</a>
				</a>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore  et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea.
				</p>
			</div>
			<div class="single-blog col-lg-4 col-md-4">
				<div class="thumb">
					<img class="f-img img-fluid mx-auto" src="img/2.jpg" alt="">	
				</div>
				<div class="bottom d-flex justify-content-between align-items-center flex-wrap">
				
					<div class="meta">
						13th Dec
					
					</div>
				</div>							
				<a href="#">
					<a href="<?php echo '?tab='.md5('journal') ?>">
						<h4>The construction of roads</h4>
					</a>
				</a>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore  et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea.
				</p>
			</div>
			<div class="single-blog col-lg-4 col-md-4">
				<div class="thumb">
					<img class="f-img img-fluid mx-auto" src="img/3.jpg" alt="">	
				</div>
				<div class="bottom d-flex justify-content-between align-items-center flex-wrap">
					
					<div class="meta">
						13th Dec
						
					</div>
				</div>							
				<a href="#">
					<a href="<?php echo '?tab='.md5('journal') ?>">
						<h4>Portable Fashion for young women</h4>
					</a>
				</a>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore  et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea.
				</p>
			</div>												
								
									
		</div>
	</div>	
</section>
<!-- end blog Area -->	