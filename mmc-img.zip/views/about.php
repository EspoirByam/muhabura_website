

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								About Us				
							</h1>	
							<p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about.html"> About Us</a></p>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start home-about Area -->
			<section class="home-about-area section-gap aboutus-about" id="about">
				<div class="container">
					<div class="row justify-content-center align-items-center">
						<div class="col-lg-8 col-md-12 home-about-left">
							<h1>
								Who are we  ? 
								
							</h1>
							
							<p class="pb-20">
								Muhabura Multichoice Company Ltd (MMC LTD.) was initiated by Rwanda Correction Service (RCS) and officially registered on 10th September 2014 by RDB as a public Company. This new multidisciplinary production and commercial entity has been established as a response to the constraints raised by intermediate suppliers of RCS that highly increased prices of goods consumed by inmates and those used for inputs to productions undertaken by RCS. The company will enable RCS to commercially exploit its productions opportunities with the aim of both benefiting RCS in terms of financial benefits and instructional (educational) benefits for the inmates.
							</p>

							<p>
							The company is currently running agriculture and construction businesses. Soap manufacturing and woodworking projects are soon to get started. However, during the review and update of this business plan, it is judged relevant to limit the company’s business portfolio to Supply, Agriculture, Construction, Soap manufacturing, Woodworking and Art Design, and Garment Manufacturing.
						</p>

                           <p>
                           The working relationship between RCS production division and MMC LTD shall continue to be governed by memoranda of understanding (MOU).
                       </p>


						<p>
						The company targets both national and regional customers. Its competitive advantage is supported by the facts that there is competent and affordable labor (inmates) that will be used to produce and deliver high quality of products and services to customers. As it is revealed by the financial (cash flow) projections for each individual business line that MMC Ltd intends to undertake, the profitability of all its business projects remains quite certain. 
						</p> 
													
							<!--<a class="primary-btn" href="#">Read More About MMC</a> -->
						</div>

					</div>
					
				</div>	
			</section>
			<!-- End home-about Area -->

			<!-- Start cat Area -->
			<section class="cat-area section-gap aboutus-cat" id="feature">
				<div class="container">							
					<div class="row">
						<div class="col-lg-4">	
							<div class="single-cat d-flex flex-column">
								<a href="#" class="hb-sm-margin mx-auto d-block"><span class="hb hb-sm inv hb-facebook-inv"><span class="lnr lnr-magic-wand"></span></span></a>
								<h4 class="mb-20" style="margin-top: 23px;">Our Mission</h4>
								<p>
										Muhabura Multichoice Company Ltd is the production, distribution and Services Company created to ensure financial sustainability of RCS by providing quality as well as affordable products and services, thus guaranteeing its profitability and market share growth.
								</p>
							</div>															
						</div>
						<div class="col-lg-4">	
							<div class="single-cat">
								<a href="#" class="hb-sm-margin mx-auto d-block"><span class="hb hb-sm inv hb-facebook-inv"><span class="lnr lnr-rocket"></span></span></a>
								<h4 class="mt-40 mb-20">Our Vision</h4>
								<p>
									To become a leading Company in production, distribution and Services in the region.
								</p>
							</div>															
						</div>
						<div class="col-lg-4">
							<div class="single-cat">
								<a href="#" class="hb-sm-margin mx-auto d-block"><span class="hb hb-sm inv hb-facebook-inv"><span class="lnr lnr-bug"></span></span></a>
								<h4 class="mt-40 mb-20">Company core values</h4>
								
								<ul style="text-align: center;">
									<li>Innovation</li>
									<li>Customer care</li>
									<li>Professionalism</li>
									<li>Teamwork</li>
									<li>Accountability</li>
									<li>Integrity</li>
									<li>Open Mindedness</li>
								</ul>
							</div>							
						</div>
					</div>
				</div>	
			</section>
			<!-- End cat Area -->						

		
				
			