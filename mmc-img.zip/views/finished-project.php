
			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Projects				
							</h1>	
							<p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="projects.html">Finished Projects</a></p>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	
				

			<!-- Start project Area -->
			<section class="project-area section-gap" id="project">
				<div class="container">
											
					<div class="row">

						 <table class="table table-condensed">
						    <thead>
						      <tr>
						        <th>Project Name</th>
						        <th>Description</th>
						        <th>Starting Date</th>
						        <th>Ending Date</th>
						      </tr>
						    </thead>
						    <tbody>
						      <tr>
						        <td>Road Construction</td>
						        <td>Construction of the Karongi road</td>
						        <td>12-5-2018</td>
						        <td>12-12-2018</td>
						      </tr>
						      <tr>
						        <td>Road Construction</td>
						        <td>Construction of the Karongi road</td>
						        <td>12-5-2018</td>
						        <td>12-12-2018</td>
						      </tr>
						      <tr>
						        <td>Road Construction</td>
						        <td>Construction of the Karongi road</td>
						        <td>12-5-2018</td>
						        <td>12-12-2018</td>
						      </tr>
						      
						    </tbody>
						  </table>		
					</div>
				</div>	
			</section>
			<!-- End project Area -->

			
				
			