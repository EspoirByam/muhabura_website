
<!-- Start Align Area -->
<div class="whole-wrap" style="padding-top: 10%">
<div class="container">
   <div class="section-top-border">

		
		<div class="row gallery-item" style="padding-top: 5px;">
				<div class="col-md-4">
				<a href="img/gallery/7.png" class="img-gal">
					<img class="img-fluid single-project" src="img/gallery/7.png" alt="">
				</a>
			</div>
			<div class="col-md-4">
				<a href="img/tea1.jpg" class="img-gal">
					<img class="img-fluid single-project" src="img/tea1.jpg" alt="">
				</a>
			</div>
			<div class="col-md-4">
				<a href="img/gallery/6.png" class="img-gal">
					<img class="img-fluid single-project" src="img/gallery/6.png" alt="">
				</a>
			</div>
		
			<div class="col-md-4">
				<a href="img/cafe.jpg" class="img-gal">
					<img class="img-fluid single-project" src="img/cafe.jpg" alt="">
				</a>
			</div>
			<div class="col-md-4">
				<a href="img/gallery/1.jpg" class="img-gal">
					<img class="img-fluid single-project" src="img/gallery/1.jpg" alt="">
				</a>
			</div>

			<div class="col-md-4">
				<a href="img/gallery/8.jpg" class="img-gal">
					<img class="img-fluid single-project" src="img/gallery/8.jpg" alt="">
				</a>
			</div>
			<div class="col-md-4">
				<a href="img/gallery/9.jpg" class="img-gal">
					<img class="img-fluid single-project" src="img/gallery/9.jpg" alt="">
				</a>
			</div>
			
			
			
		</div>
	</div>
</div>
</div>