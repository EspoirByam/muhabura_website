    
<!-- start banner Area -->
<section class="banner-area relative" id="home">	
	<div class="overlay overlay-bg"></div>
	<div class="container">				
		<div class="row d-flex align-items-center justify-content-center">
			<div class="about-content col-lg-12">
				<h1 class="text-white">
					Videos		
				</h1>	
				<p class="text-white link-nav"><a href="#">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="#"> Videos</a></p>
			</div>	
		</div>
	</div>
</section>
<!-- End banner Area -->


<!-- Start Align Area -->
<div class="whole-wrap">
	<div class="container">
	   <div class="row" style="padding-top: 5%; padding-bottom: 5%;">
			<div class="col-sm-6">
		<div class="embed-responsive embed-responsive-16by9">
		    <iframe class="embed-responsive-item" src="//www.youtube.com/embed/ePbKGoIGAXY"></iframe>
		</div>
    </div>

    <div class="col-sm-6">      	
		<div class="embed-responsive embed-responsive-16by9">
		    <iframe class="embed-responsive-item" src="//www.youtube.com/embed/ePbKGoIGAXY"></iframe>
		</div>
    </div>
			
		</div>
	</div>


</div>